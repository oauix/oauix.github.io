package xyu.cn.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import xyu.cn.entity.User;
import xyu.cn.service.LoginService;

/**
 * ��¼ע�������
 * @author oauix
 *
 */
@Controller
public class LoginController {
	
	@Resource(name="loginService")
	private LoginService loginService;
	//test
	@RequestMapping("/hi")
	public String HelloWord(){
		System.out.println("test go");
		return "hello";	
	}
	//login
	@RequestMapping("/login")
	public String login(){
		System.out.println("�����¼ҳ�棡");
		return "login";
	}
	//regset
	@RequestMapping("/regset")
	public String reg(){
		System.out.println("����ע��ҳ�棡");
		return "regset";
	}
	@RequestMapping("/add")
	public String add(User user){
		System.out.println("sign up!");
		System.out.println(user.getName()+","+user.getPassword());
		boolean fag=loginService.add(user);
		if(fag){
			System.out.println("����ɹ�");
			System.out.println(user.getType());
		}else{
			System.out.println("error!");
		}
		return "login";
	}
	@RequestMapping("/bypassword")
	public String findByName(User user){
		System.out.println("go login!");
		System.out.println(user.getName()+","+user.getPassword());
		boolean falg=loginService.findByPassword(user);
		int type=loginService.findByType(user.getName());
		user.setType(type);
		if(falg){
			System.out.println("��¼�ɹ�");
			return "hello";
		}else{
			System.out.println("error!");
		}
		return "login";
	}
}
