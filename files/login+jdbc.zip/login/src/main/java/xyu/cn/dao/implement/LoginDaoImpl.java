package xyu.cn.dao.implement;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import xyu.cn.dao.LoginDao;
import xyu.cn.entity.User;

@Repository("loginDao")
public class LoginDaoImpl implements LoginDao {
	//�Զ�ע������
	@Autowired  
    private JdbcTemplate jdbcTemplate;
	
	//�÷�����Ϊ�˲���ʱ��jdbcTemplate���Ը�ֵ��,�����Զ�ע��
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public boolean add(User user) {
		String sqlStr = "insert into user(name,password) values(?,?)";  
        Object[] params = new Object[]{user.getName(),user.getPassword()};  
        int msg=jdbcTemplate.update(sqlStr, params);
        if(msg>0){
        	return true;
        }
		return false;
	}
	public String findByPassword(String name){
		String sqlStr = "select password from user where name=?";
		try{
			//�򵥵Ĳ�ѯһ����¼
			String resutl=(String)jdbcTemplate.queryForObject(sqlStr, new Object[]{name},java.lang.String.class);
			return resutl;
		}catch(Exception e){
			e.printStackTrace();
			return "�˺Ų����ڣ�";
			
		}
	}
	//��ѯ�˺�����
	public String findByType(String name){
		String sqlStr = "select type from user where name=?";  
		//RowMapper<User> rowMapper=new BeanPropertyRowMapper<User>(User.class);
		try{
			//�򵥵Ĳ�ѯһ����¼
			String resutl=(String)jdbcTemplate.queryForObject(sqlStr, new Object[]{name},java.lang.String.class);
			return resutl;
		}catch(Exception e){
			//e.printStackTrace();
			return "�˺Ų����ڣ�";
			
		}
	}
	//�����˺�����
	public boolean setByType(User user){
		String sqlStr="update user set type=? where name=?";
		Object[] params = new Object[]{user.getType(),user.getName()};
		int msg=jdbcTemplate.update(sqlStr, params);
		if(msg>0)
			return true;
		return false;
	}
	//��������
	public int updata(User user){
		String sqlStr="update user set name=?,passwoed=?,type=? where id=?";
		Object[] params = new Object[]{user.getName(),user.getPassword(),
				user.getType(),user.getId()};
		int msg=jdbcTemplate.update(sqlStr, params);
		return msg;
	}
	/**
	 * ɾ������
	 */
	public int delete(int id){		
		String sqlStr="delete from user where id=?";
		Object[] params = new Object[]{id};
		int msg=jdbcTemplate.update(sqlStr, params);
		return msg;
	}
	/**
	 * ��ѯȫ������
	 */
	public List findList(){
		String sqlStr = "select * from user";
		List rows=jdbcTemplate.queryForList(sqlStr);
		return rows;
	}
}
