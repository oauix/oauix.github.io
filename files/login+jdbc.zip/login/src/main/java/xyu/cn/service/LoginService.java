package xyu.cn.service;

import xyu.cn.entity.User;

public interface LoginService {
	public boolean add(User user);
	public boolean findByPassword(User user);
	public int findByType(String name);
}
