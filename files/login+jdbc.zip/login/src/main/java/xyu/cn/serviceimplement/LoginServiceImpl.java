package xyu.cn.serviceimplement;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import xyu.cn.dao.LoginDao;
import xyu.cn.entity.User;
import xyu.cn.service.LoginService;
@Service("loginService")
public class LoginServiceImpl implements LoginService {
	
	@Resource(name="loginDao")
	private LoginDao loginDao;
	public boolean add(User user) {
		return loginDao.add(user);
	}
	public boolean findByPassword(User user) {
		String pwd=loginDao.findByPassword(user.getName());
		System.out.println(pwd);
		if(user.getPassword().equals(pwd))
			return true;		
		return false;
	}
	public int findByType(String name){
		String str=loginDao.findByType(name);
		if(!"�˺Ų����ڣ�".equals(str)){
			return Integer.parseInt(str);
		}
		return 0;
	}
}
