package SessionFtyTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import xyu.cn.dao.LoginDao;
import xyu.cn.entity.User;

public class SessionFtyTest {
	private ApplicationContext ctx;
	@Before
	public void testno1(){
		//���ApplicationContext����
		ctx=new ClassPathXmlApplicationContext(
			"spring-webmvc.xml",
			"spring-pool.xml",
			"spring-mybatis.xml");
			
			Object bean=
			ctx.getBean("sqlSessionFactory");
			
			System.out.println(bean);
			
			Assert.assertNotEquals(null, bean);
	}
	@Test
	public void testno2(){
		//���DAO����
		LoginDao dao=(LoginDao)ctx.getBean("loginDao");
		
		User user=new User();
		user.setName("oauix");
		user.setPassword("250130");
		
		boolean n=dao.add(user);
		Assert.assertEquals(true, n);
	}
}
