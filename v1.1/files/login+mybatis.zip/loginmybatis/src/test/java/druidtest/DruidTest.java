package druidtest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.druid.pool.DruidDataSource;

public class DruidTest {
	ApplicationContext ctx;
	@Before
	public void init(){
		ctx=new ClassPathXmlApplicationContext("spring-pool.xml");
	}
	@Test
	public void poolTest(){
		DruidDataSource dataSource=(DruidDataSource)ctx.getBean("dataSource");
		System.out.println(dataSource);
		Assert.assertNotEquals(dataSource, null);
	}
	@Test
	public void testSessionFactory() {
			ApplicationContext ctx=
			new ClassPathXmlApplicationContext("spring-webmvc.xml","spring-pool.xml","spring-mybatis.xml"); 
			Object sessionFactory=ctx.getBean("sqlSessionFactory");
			System.out.println(sessionFactory);
			Assert.assertNotEquals(sessionFactory, null);
	}
}

