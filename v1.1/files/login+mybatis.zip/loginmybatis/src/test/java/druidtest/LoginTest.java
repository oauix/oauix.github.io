package druidtest;

import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.jdbc.ScriptRunner;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import xyu.cn.entity.User;



public class LoginTest {
	private static SqlSessionFactory sqlSessionFactory;
	@Before
	public void init() throws IOException{
		Reader reader = Resources.getResourceAsReader("spring-mybatis.xml");
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);  
        System.out.println(sqlSessionFactory);
	}
	@Test
	public void add(){
		SqlSession session=sqlSessionFactory.openSession();
		User user=new User();
		user.setName("oauix");
		user.setPassword("250130");
		session.insert("add",user);
		session.commit();
		session.close();
	}
}
